# Base Conecta4G — extração inicial do APK

Arquivo recebido: Base_Conecta4G_descriptografada_+_transparente_barra_navegação.apk
SHA-256: 056509b1123b2fea6cb1e5b79b7fedc2dae49e4a5047f9c3a471e3215b04f7ae

O APK foi descompactado. Esta pasta contém os 839 itens internos, incluindo `classes.dex`, manifesto Android binário, recursos, assets e bibliotecas nativas.

Bibliotecas nativas identificadas: `libtun2socks.so`, `libpdnsd.so`, `libconscrypt_jni.so` e `libtool-checker.so`, para arm64-v8a, armeabi-v7a, x86 e x86_64.

Strings do DEX indicam componentes dos pacotes `com.conecta4g.vpn` e `com.romzkie.ultrasshservice`.

**Importante:** APK não é projeto-fonte Android Studio. Esta extração ainda não é um projeto compilável. Para avançar, precisamos decodificar o manifesto/recursos com Apktool e decompilar `classes.dex` com JADX. Mesmo assim, a reconstrução não recupera necessariamente o código original, comentários, nomes locais nem arquivos Gradle.

O APK inclui `assets/config/config.json` com endereços e configurações de servidores/serviços. Não publicar o APK original nem essa configuração operacional em repositório público sem revisar e remover dados sensíveis/de terceiros.
